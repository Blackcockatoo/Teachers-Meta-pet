import {
  decodeGenome,
  getTraitSummary,
  encodeGenome,
  generateRandomGenome,
  genomeHeptaSignature,
  genomeChargeVector,
  genomeBridgeScore,
  summarizeElementWeb,
  getResidueMeta,
} from './index';
import type { Genome } from './types';

// ---- WebCrypto adapter (HMAC-SHA256 + SHA-256) ----
const textEncoder = new TextEncoder();

function toHex(buf: ArrayBuffer): string {
  const bytes = new Uint8Array(buf);
  let out = '';
  for (let i = 0; i < bytes.length; i++) {
    out += bytes[i].toString(16).padStart(2, '0');
  }
  return out;
}

async function sha256(data: string): Promise<string> {
  const digest = await crypto.subtle.digest('SHA-256', textEncoder.encode(data));
  return toHex(digest);
}

async function hmacSHA256(data: string, key: string): Promise<string> {
  const cryptoKey = await crypto.subtle.importKey(
    'raw',
    textEncoder.encode(key),
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign']
  );
  const sig = await crypto.subtle.sign('HMAC', cryptoKey, textEncoder.encode(data));
  return toHex(sig);
}

const cryptoAdapter = { sha256, hmacSHA256 };

// ---- Helpers ----
function clampBase7(n: number): number {
  if (!Number.isFinite(n)) return 0;
  const r = Math.floor(n);
  return Math.max(0, Math.min(6, r));
}

function digitsFromString(s: string): number[] {
  const cleaned = (s || '').replace(/\s+/g, '');
  if (!cleaned) return [];
  const out: number[] = [];
  for (const ch of cleaned) {
    if (ch < '0' || ch > '6') continue;
    out.push(ch.charCodeAt(0) - 48);
  }
  return out;
}

function padTo60(arr: number[]): number[] {
  const out = arr.slice(0, 60);
  while (out.length < 60) out.push(0);
  return out;
}

function genomeToText(g: Genome): string {
  return [g.red60.join(''), g.blue60.join(''), g.black60.join('')].join('\n');
}

function parseGenome(text: string): Genome {
  const trimmed = (text || '').trim();
  // JSON support
  if (trimmed.startsWith('{')) {
    const obj = JSON.parse(trimmed) as Genome;
    return {
      red60: padTo60((obj.red60 ?? []).map(clampBase7)),
      blue60: padTo60((obj.blue60 ?? []).map(clampBase7)),
      black60: padTo60((obj.black60 ?? []).map(clampBase7)),
    };
  }

  const lines = trimmed.split(/\r?\n/).filter(Boolean);
  const [r, b, k] = lines;
  const red60 = padTo60(digitsFromString(r || ''));
  const blue60 = padTo60(digitsFromString(b || ''));
  const black60 = padTo60(digitsFromString(k || ''));
  return { red60, blue60, black60 };
}

function $(sel: string): HTMLElement {
  const el = document.querySelector(sel);
  if (!el) throw new Error(`Missing element: ${sel}`);
  return el as HTMLElement;
}

function setOut(title: string, obj: unknown): void {
  const pre = $('#out') as HTMLPreElement;
  const header = $('#outTitle') as HTMLDivElement;
  header.textContent = title;
  pre.textContent = typeof obj === 'string' ? obj : JSON.stringify(obj, null, 2);
}

function setStatus(msg: string): void {
  ($('#status') as HTMLDivElement).textContent = msg;
}

function currentGenome(): Genome {
  return parseGenome(($('#genomeText') as HTMLTextAreaElement).value);
}

function updateGenomeText(g: Genome): void {
  ($('#genomeText') as HTMLTextAreaElement).value = genomeToText(g);
}

// ---- UI Actions ----
async function actionEncode(): Promise<void> {
  const primeDNA = ($('#primeDNA') as HTMLInputElement).value;
  const tailDNA = ($('#tailDNA') as HTMLInputElement).value;
  if (!primeDNA || !tailDNA) {
    setStatus('Need both Prime DNA and Tail DNA to encode.');
    return;
  }
  setStatus('Encoding…');
  const genome = await encodeGenome(primeDNA, tailDNA, cryptoAdapter);
  updateGenomeText(genome);
  setOut('Encoded Genome (base-7 arrays)', genome);
  setStatus('Encoded.');
}

function actionRandom(): void {
  const genome = generateRandomGenome();
  updateGenomeText(genome);
  setOut('Random Genome', genome);
  setStatus('Randomized.');
}

function actionDecode(): void {
  const genome = currentGenome();
  const traits = decodeGenome(genome);
  const summary = getTraitSummary(traits);
  setOut('Decoded Traits + Summary', { summary, traits });
  setStatus('Decoded.');
}

function actionElementWeb(): void {
  const genome = currentGenome();
  const web = summarizeElementWeb(genome);
  setOut('Element Web Summary', web);
  setStatus('Computed element web.');
}

function actionHepta(): void {
  const genome = currentGenome();
  const sig = genomeHeptaSignature(genome);
  setOut('Hepta Signature (genome)', sig);
  setStatus('Computed hepta signature.');
}

function actionCharge(): void {
  const genome = currentGenome();
  const vec = genomeChargeVector(genome);
  setOut('Charge Vector (genome)', vec);
  setStatus('Computed charge vector.');
}

function actionBridge(): void {
  const a = parseGenome(($('#genomeA') as HTMLTextAreaElement).value);
  const b = parseGenome(($('#genomeB') as HTMLTextAreaElement).value);
  const score = genomeBridgeScore(a, b);
  setOut('Bridge Score (A ↔ B)', { score });
  setStatus('Computed bridge score.');
}

function actionResidue(): void {
  const n = Number(($('#residueNumber') as HTMLInputElement).value);
  if (!Number.isFinite(n)) {
    setStatus('Enter a residue (0–59).');
    return;
  }
  const meta = getResidueMeta(n);
  setOut(`Residue Meta: ${n}`, meta);
  setStatus('Fetched residue meta.');
}

function wire(): void {
  ($('#btnEncode') as HTMLButtonElement).addEventListener('click', () => {
    actionEncode().catch(err => setOut('Error (encode)', String(err)));
  });
  ($('#btnRandom') as HTMLButtonElement).addEventListener('click', actionRandom);
  ($('#btnDecode') as HTMLButtonElement).addEventListener('click', actionDecode);
  ($('#btnElementWeb') as HTMLButtonElement).addEventListener('click', actionElementWeb);
  ($('#btnHepta') as HTMLButtonElement).addEventListener('click', actionHepta);
  ($('#btnCharge') as HTMLButtonElement).addEventListener('click', actionCharge);
  ($('#btnBridge') as HTMLButtonElement).addEventListener('click', actionBridge);
  ($('#btnResidue') as HTMLButtonElement).addEventListener('click', actionResidue);

  // seed example
  const seed = generateRandomGenome();
  updateGenomeText(seed);
  ($('#genomeA') as HTMLTextAreaElement).value = genomeToText(seed);
  ($('#genomeB') as HTMLTextAreaElement).value = genomeToText(generateRandomGenome());
}

wire();
